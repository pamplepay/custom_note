"""
URL configuration for Cust_Note project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render, redirect
from django.conf import settings
from django.conf.urls.static import static
from django.http import JsonResponse, HttpResponse, Http404
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
import json
import os

# Swagger 스키마 뷰 설정
schema_view = get_schema_view(
    openapi.Info(
        title="Oil Note API",
        default_version='v1',
        description="Oil Note 서비스의 API 문서입니다.",
        terms_of_service="https://www.google.com/policies/terms/",
        contact=openapi.Contact(email="contact@oilnote.com"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

def home(request):
    # 로그인한 사용자는 해당 메인 페이지로 리다이렉트
    if request.user.is_authenticated:
        if request.user.user_type == 'CUSTOMER':
            return redirect('customer:main')
        elif request.user.user_type == 'STATION':
            return redirect('station:main')
    
    return render(request, 'home.html')

def manifest_view(request):
    # 현재 요청의 호스트와 포트를 기반으로 동적 매니페스트 생성
    host = request.get_host()
    scheme = request.scheme
    base_url = f"{scheme}://{host}"
    
    manifest_data = {
        "name": "Oil Note - 주유소 관리 시스템",
        "short_name": "Oil Note",
        "description": "주유소와 고객을 위한 스마트한 관리 시스템",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#ffffff",
        "theme_color": "#007bff",
        "orientation": "portrait-primary",
        "scope": "/",
        "lang": "ko-KR",
        "categories": ["business", "productivity"],
        "icons": [
            {
                "src": "/icon-192x192.png",
                "sizes": "192x192",
                "type": "image/png",
                "purpose": "maskable"
            },
            {
                "src": "/icon-512x512.png",
                "sizes": "512x512",
                "type": "image/png",
                "purpose": "any"
            }
        ],
        "screenshots": [
            {
                "src": "/screenshots/desktop.png",
                "sizes": "1280x800",
                "type": "image/png",
                "form_factor": "wide"
            },
            {
                "src": "/screenshots/mobile.png",
                "sizes": "750x1334",
                "type": "image/png",
                "form_factor": "narrow"
            }
        ],
        "id": "oil-note-pwa-v1"
    }
    
    response = JsonResponse(manifest_data, content_type='application/manifest+json')
    response['Content-Type'] = 'application/manifest+json; charset=utf-8'
    return response

def icon_192_view(request):
    """192x192 아이콘을 서빙합니다."""
    icon_path = os.path.join(settings.BASE_DIR, 'static/pwa/icons/icon-192x192.png')
    try:
        with open(icon_path, 'rb') as f:
            image_data = f.read()
        return HttpResponse(image_data, content_type='image/png')
    except FileNotFoundError:
        raise Http404("Icon not found")

def icon_512_view(request):
    """512x512 아이콘을 서빙합니다."""
    icon_path = os.path.join(settings.BASE_DIR, 'static/pwa/icons/icon-512x512.png')
    try:
        with open(icon_path, 'rb') as f:
            image_data = f.read()
        return HttpResponse(image_data, content_type='image/png')
    except FileNotFoundError:
        raise Http404("Icon not found")

def service_worker_view(request):
    """Service Worker 파일을 서빙합니다."""
    sw_path = os.path.join(settings.BASE_DIR, 'sw.js')
    try:
        with open(sw_path, 'r', encoding='utf-8') as f:
            sw_content = f.read()
        return HttpResponse(sw_content.encode('utf-8'), content_type='application/javascript')
    except FileNotFoundError:
        raise Http404("Service Worker not found")

urlpatterns = [
    path('', home, name='home'),
    path('admin/', admin.site.urls),
    path('users/', include('Cust_User.urls')),
    path('customer/', include('Cust_UserApp.urls')),
    path('station/', include('Cust_StationApp.urls')),
    
    # PWA 매니페스트
    path('manifest.json', manifest_view, name='manifest'),
    
    # PWA 아이콘
    path('icon-192x192.png', icon_192_view, name='icon_192'),
    path('icon-512x512.png', icon_512_view, name='icon_512'),
    
    # Service Worker
    path('sw.js', service_worker_view, name='service_worker'),
    
    # Favicon
    path('favicon.ico', lambda request: redirect('/static/favicon.svg')),
    
    # Swagger URL
    path('swagger<format>/', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
]

# 정적 파일 및 미디어 파일 서빙 (개발 환경에서만)
# CDN 사용으로 인해 정적 파일 서빙은 개발 환경에서만 필요
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
