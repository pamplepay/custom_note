from django.db import models
from django.utils import timezone
from Cust_User.models import CustomUser

# Create your models here.

class PointCard(models.Model):
    number = models.CharField(max_length=16, unique=True, verbose_name='카드번호')
    is_used = models.BooleanField(default=False, verbose_name='사용 여부')
    created_at = models.DateTimeField(default=timezone.now, verbose_name='등록일')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='수정일')
    
    # 카드를 등록한 주유소들
    stations = models.ManyToManyField(
        CustomUser,
        through='StationCardMapping',
        related_name='registered_cards',
        limit_choices_to={'user_type': 'STATION'},
        verbose_name='등록 주유소'
    )

    class Meta:
        verbose_name = '포인트카드'
        verbose_name_plural = '포인트카드'
        ordering = ['-created_at']

    def __str__(self):
        return f"카드 {self.number} ({'사용중' if self.is_used else '미사용'})"

class StationCardMapping(models.Model):
    station = models.ForeignKey(
        CustomUser, 
        on_delete=models.CASCADE, 
        limit_choices_to={'user_type': 'STATION'},
        verbose_name='주유소'
    )
    card = models.ForeignKey(
        PointCard, 
        on_delete=models.CASCADE,
        verbose_name='포인트카드'
    )
    registered_at = models.DateTimeField(default=timezone.now, verbose_name='등록일')
    is_active = models.BooleanField(default=True, verbose_name='활성화 여부')

    class Meta:
        verbose_name = '주유소-카드 매핑'
        verbose_name_plural = '주유소-카드 매핑'
        unique_together = ('station', 'card')
        ordering = ['-registered_at']

    def __str__(self):
        return f"{self.station.username}의 카드 {self.card.number}"

class StationList(CustomUser):
    class Meta:
        proxy = True
        verbose_name = '주유소'
        verbose_name_plural = '주유소 목록'
