from django.apps import AppConfig


class CustStationappConfig(AppConfig):
    name = "Cust_StationApp"
    verbose_name = '주유소 관리'
