from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.contrib import messages
from django.db.models import Q
from Cust_User.models import CustomUser, CustomerProfile, CustomerStationRelation
from .models import PointCard, StationCardMapping
from datetime import datetime, timedelta
import json
import logging
import re
from django.utils import timezone

logger = logging.getLogger(__name__)

@login_required
def station_main(request):
    """주유소 메인 페이지"""
    if not request.user.is_station:
        messages.error(request, '주유소 회원만 접근할 수 있습니다.')
        return redirect('home')
    
    # 카드 통계
    total_cards = StationCardMapping.objects.filter(station=request.user).count()
    active_cards = StationCardMapping.objects.filter(station=request.user, is_active=True).count()
    inactive_cards = StationCardMapping.objects.filter(station=request.user, is_active=False).count()
    
    context = {
        'total_cards': total_cards,
        'active_cards': active_cards,
        'inactive_cards': inactive_cards,
    }
    return render(request, 'Cust_Station/station_main.html', context)

@login_required
def station_management(request):
    """주유소 관리 페이지"""
    if not request.user.is_station:
        messages.error(request, '주유소 회원만 접근할 수 있습니다.')
        return redirect('home')
    
    # 현재 주유소의 카드 매핑 수 조회
    mappings = StationCardMapping.objects.filter(station=request.user)
    total_cards = mappings.count()
    active_cards = mappings.filter(is_active=True, card__is_used=False).count()
    inactive_cards = mappings.filter(is_active=True, card__is_used=True).count()
    
    # 비율 계산
    active_percentage = (active_cards / total_cards * 100) if total_cards > 0 else 0
    inactive_percentage = (inactive_cards / total_cards * 100) if total_cards > 0 else 0
    
    context = {
        'total_cards': total_cards,
        'active_cards': active_cards,
        'inactive_cards': inactive_cards,
        'active_percentage': active_percentage,
        'inactive_percentage': inactive_percentage,
    }
    
    return render(request, 'Cust_Station/station_management.html', context)

@login_required
def station_profile(request):
    """주유소 프로필 페이지"""
    if not request.user.is_station:
        messages.error(request, '주유소 회원만 접근할 수 있습니다.')
        return redirect('home')
    
    # 현재 주유소 프로필 가져오기 또는 생성
    try:
        station_profile = request.user.station_profile
    except:
        from Cust_User.models import StationProfile
        station_profile = StationProfile(user=request.user)
        station_profile.save()
    
    if request.method == 'POST':
        # POST 요청 처리
        station_profile.station_name = request.POST.get('station_name')
        station_profile.station_phone = request.POST.get('station_phone')
        station_profile.station_address = request.POST.get('station_address')
        station_profile.business_number = request.POST.get('business_number')
        station_profile.owner_name = request.POST.get('owner_name')
        
        try:
            station_profile.save()
            messages.success(request, '주유소 정보가 성공적으로 업데이트되었습니다.')
            return redirect('station:profile')
        except Exception as e:
            messages.error(request, f'정보 업데이트 중 오류가 발생했습니다: {str(e)}')
    
    # GET 요청 처리
    context = {
        'station_name': station_profile.station_name,
        'station_phone': station_profile.station_phone,
        'station_address': station_profile.station_address,
        'business_number': station_profile.business_number,
        'owner_name': station_profile.owner_name,
    }
    
    return render(request, 'Cust_Station/station_profile.html', context)

@login_required
def station_cardmanage(request):
    """주유소 카드 관리 페이지"""
    if not request.user.is_station:
        messages.error(request, '주유소 회원만 접근할 수 있습니다.')
        return redirect('home')
    
    # 현재 주유소의 카드 매핑 수 조회
    mappings = StationCardMapping.objects.filter(station=request.user)
    total_cards = mappings.filter(is_active=True).count()
    
    # 카드 상태별 통계
    active_cards = mappings.filter(is_active=True, card__is_used=False).count()
    used_cards = mappings.filter(is_active=True, card__is_used=True).count()
    
    # 비율 계산
    active_percentage = (active_cards / total_cards * 100) if total_cards > 0 else 0
    used_percentage = (used_cards / total_cards * 100) if total_cards > 0 else 0
    
    # 최근 등록된 카드 3장 가져오기
    recent_cards = StationCardMapping.objects.select_related('card').filter(
        station=request.user,
        is_active=True
    ).order_by('-registered_at')[:3]
    
    cards_data = []
    for mapping in recent_cards:
        card = mapping.card
        cards_data.append({
            'number': card.number,
            'is_used': card.is_used,
            'created_at': mapping.registered_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    context = {
        'total_cards': total_cards,
        'active_cards': active_cards,
        'used_cards': used_cards,
        'active_percentage': active_percentage,
        'used_percentage': used_percentage,
        'station_name': request.user.username,
        'recent_cards': cards_data
    }
    
    return render(request, 'Cust_Station/station_cardmanage.html', context)

@login_required
def station_usermanage(request):
    """주유소 회원 관리 페이지"""
    if not request.user.is_station:
        messages.error(request, '주유소 회원만 접근할 수 있습니다.')
        return redirect('home')
    
    # GET 파라미터에서 검색어 가져오기
    search_query = request.GET.get('search', '')
    
    # 기본 쿼리셋: 일반 고객만 필터링
    customers = CustomUser.objects.filter(user_type='CUSTOMER')
    
    # 검색어가 있는 경우 필터링
    if search_query:
        customers = customers.filter(
            Q(username__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(customer_profile__customer_phone__icontains=search_query)
        )
    
    # 페이지당 표시할 회원 수
    customers_per_page = 10
    
    # 현재 페이지 번호
    page = request.GET.get('page', 1)
    try:
        page = int(page)
    except ValueError:
        page = 1
    
    # 전체 회원 수
    total_customers = customers.count()
    
    # 전체 페이지 수 계산
    total_pages = (total_customers + customers_per_page - 1) // customers_per_page
    
    # 시작 인덱스와 끝 인덱스 계산
    start_idx = (page - 1) * customers_per_page
    end_idx = start_idx + customers_per_page
    
    # 현재 페이지의 회원 목록
    current_customers = customers[start_idx:end_idx]
    
    # 페이지네이션 범위 계산
    max_pages = 5
    if total_pages <= max_pages:
        page_range = range(1, total_pages + 1)
    else:
        if page <= max_pages // 2:
            page_range = range(1, max_pages + 1)
        elif page > total_pages - max_pages // 2:
            page_range = range(total_pages - max_pages + 1, total_pages + 1)
        else:
            page_range = range(page - max_pages // 2, page + max_pages // 2 + 1)
    
    # 회원 정보를 딕셔너리 리스트로 변환
    customers_data = []
    for customer in current_customers:
        try:
            profile = customer.customer_profile
            phone_number = profile.customer_phone if profile else ''
            bonus_card = profile.bonus_card if profile else ''
            # 최근 방문일은 나중에 구현
            last_visit = '-'
        except CustomerProfile.DoesNotExist:
            phone_number = ''
            bonus_card = ''
            last_visit = '-'
        
        customers_data.append({
            'id': customer.id,
            'username': customer.username,
            'phone_number': phone_number,
            'bonus_card': bonus_card,
            'last_visit': last_visit
        })
    
    context = {
        'customers': customers_data,
        'total_pages': total_pages,
        'current_page': page,
        'page_range': list(page_range),
        'search_query': search_query,
    }
    
    # AJAX 요청인 경우 JSON 응답
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse(context)
    
    return render(request, 'Cust_Station/station_usermanage.html', context)

@login_required
def update_customer_info(request):
    """고객 정보 업데이트"""
    if not request.user.is_station:
        return JsonResponse({'error': '권한이 없습니다.'}, status=403)
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            customer_id = data.get('customer_id')
            phone = data.get('phone', '').strip()
            card_number = data.get('cardNumber', '').strip()
            
            customer = get_object_or_404(CustomUser, id=customer_id, user_type='CUSTOMER')
            
            # CustomerProfile 가져오기 또는 생성
            profile, created = CustomerProfile.objects.get_or_create(user=customer)
            
            # 전화번호와 카드번호 업데이트
            if phone:
                profile.customer_phone = phone
            if card_number:
                profile.bonus_card = card_number
            
            profile.save()
            
            return JsonResponse({
                'success': True,
                'message': '고객 정보가 업데이트되었습니다.',
                'phone': profile.customer_phone,
                'cardNumber': profile.bonus_card
            })
            
        except json.JSONDecodeError:
            return JsonResponse({'error': '잘못된 요청 형식입니다.'}, status=400)
        except CustomUser.DoesNotExist:
            return JsonResponse({'error': '고객을 찾을 수 없습니다.'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    return JsonResponse({'error': '잘못된 요청 방식입니다.'}, status=405)

@login_required
def get_cards(request):
    """등록된 카드 목록 조회"""
    if not request.user.is_station:
        logger.warning(f"권한 없는 사용자의 접근 시도: {request.user.username}")
        return JsonResponse({'status': 'error', 'message': '권한이 없습니다.'}, status=403)
    
    try:
        # 현재 주유소에 등록된 카드 매핑 조회
        mappings = StationCardMapping.objects.select_related('card').filter(
            station=request.user,
            is_active=True
        ).order_by('-registered_at')
        
        total_count = mappings.count()
        logger.info(f"주유소 {request.user.username}의 등록 카드 수: {total_count}")
        
        cards_data = []
        for mapping in mappings:
            card = mapping.card
            card_info = {
                'number': card.number,
                'is_used': card.is_used,
                'created_at': mapping.registered_at.strftime('%Y-%m-%d %H:%M:%S')
            }
            cards_data.append(card_info)
            logger.debug(f"카드 정보: {card_info}")
        
        logger.info(f"조회된 카드 수: {len(cards_data)}")
        
        # 통계 정보 계산
        active_count = sum(1 for card in cards_data if not card['is_used'])
        used_count = sum(1 for card in cards_data if card['is_used'])
        
        logger.info(f"통계 정보 - 전체: {total_count}, 사용가능: {active_count}, 사용중: {used_count}")
        
        return JsonResponse({
            'status': 'success',
            'cards': cards_data,
            'total_count': total_count,
            'active_count': active_count,
            'used_count': used_count
        })
    except Exception as e:
        logger.error(f"카드 목록 조회 중 오류 발생: {str(e)}", exc_info=True)
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=500)

@login_required
def register_cards_bulk(request):
    """카드 일괄 등록"""
    if not request.user.is_station:
        return JsonResponse({'status': 'error', 'message': '권한이 없습니다.'}, status=403)
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            start_number = data.get('startNumber', '').strip()
            card_count = int(data.get('cardCount', 0))
            
            # 입력 검증
            if not start_number or len(start_number) != 16 or not start_number.isdigit():
                return JsonResponse({
                    'status': 'error',
                    'message': '시작 번호는 16자리 숫자여야 합니다.'
                })
            
            if card_count < 1 or card_count > 1000:
                return JsonResponse({
                    'status': 'error',
                    'message': '카드 수는 1~1000 사이여야 합니다.'
                })
            
            start_num = int(start_number)
            created_cards = []
            duplicate_cards = []
            
            for i in range(card_count):
                card_number = str(start_num + i).zfill(16)
                
                try:
                    # get_or_create를 사용하여 중복 생성 방지
                    card, created = PointCard.objects.get_or_create(number=card_number)
                    
                    # 카드와 주유소 매핑 생성
                    mapping, mapping_created = StationCardMapping.objects.get_or_create(
                        station=request.user,
                        card=card,
                        defaults={'is_active': True}
                    )
                    
                    # 매핑이 이미 존재하지만 비활성화된 경우 활성화
                    if not mapping_created and not mapping.is_active:
                        mapping.is_active = True
                        mapping.save()
                    
                    if created:
                        created_cards.append(card_number)
                        logger.info(f"새 카드 등록: {card_number} (주유소: {request.user.username})")
                    else:
                        if mapping_created:
                            logger.info(f"기존 카드 매핑: {card_number} (주유소: {request.user.username})")
                        duplicate_cards.append(card_number)
                        
                except Exception as e:
                    logger.error(f"카드 등록 중 오류: {card_number}, {str(e)}")
                    duplicate_cards.append(card_number)
            
            message = f'{len(created_cards)}개의 카드가 등록되었습니다.'
            if duplicate_cards:
                message += f' (중복 {len(duplicate_cards)}개 제외)'
            
            return JsonResponse({
                'status': 'success',
                'message': message,
                'created_count': len(created_cards),
                'duplicate_count': len(duplicate_cards)
            })
            
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': '잘못된 요청 형식입니다.'
            }, status=400)
        except ValueError:
            return JsonResponse({
                'status': 'error',
                'message': '숫자 형식이 올바르지 않습니다.'
            }, status=400)
        except Exception as e:
            logger.error(f"카드 일괄 등록 중 오류 발생: {str(e)}", exc_info=True)
            return JsonResponse({
                'status': 'error',
                'message': f'카드 등록 중 오류가 발생했습니다: {str(e)}'
            }, status=500)
    
    return JsonResponse({'status': 'error', 'message': '잘못된 요청 방식입니다.'}, status=405)

@login_required
def register_cards_single(request):
    """카드 개별 등록"""
    logger.info(f"개별 카드 등록 요청 - 사용자: {request.user.username}, 메소드: {request.method}")
    
    if not request.user.is_station:
        logger.warning(f"권한 없는 사용자의 카드 등록 시도: {request.user.username}")
        return JsonResponse({'status': 'error', 'message': '권한이 없습니다.'}, status=403)
    
    if request.method == 'POST':
        try:
            logger.info(f"요청 본문: {request.body.decode('utf-8')}")
            data = json.loads(request.body)
            card_number = data.get('cardNumber', '').strip()
            logger.info(f"추출된 카드번호: '{card_number}'")
            
            # 입력 검증
            if not card_number or len(card_number) != 16 or not card_number.isdigit():
                logger.warning(f"잘못된 카드번호 형식: '{card_number}' (길이: {len(card_number) if card_number else 0})")
                return JsonResponse({
                    'status': 'error',
                    'message': '카드번호는 16자리 숫자여야 합니다.'
                })
            
            logger.info(f"카드 생성 시도: {card_number}")
            # get_or_create를 사용하여 중복 생성 방지
            card, created = PointCard.objects.get_or_create(number=card_number)
            logger.info(f"카드 생성 결과: created={created}, card_id={card.id}")
            
            # 카드와 주유소 매핑 생성
            logger.info(f"매핑 생성 시도: 주유소={request.user.username}, 카드={card_number}")
            mapping, mapping_created = StationCardMapping.objects.get_or_create(
                station=request.user,
                card=card,
                defaults={'is_active': True}
            )
            logger.info(f"매핑 생성 결과: created={mapping_created}, mapping_id={mapping.id}")
            
            # 매핑 상태에 따른 처리
            if not mapping_created:
                if mapping.is_active:
                    # 이미 활성화된 매핑이 존재
                    logger.warning(f"중복 카드 등록 시도: {card_number} (주유소: {request.user.username})")
                    return JsonResponse({
                        'status': 'error',
                        'message': f'카드 {card_number}은 이미 이 주유소에 등록되어 있습니다.'
                    })
                else:
                    # 비활성화된 매핑 재활성화
                    mapping.is_active = True
                    mapping.save()
                    logger.info(f"비활성 매핑 재활성화: {mapping.id}")
                    return JsonResponse({
                        'status': 'success',
                        'message': f'삭제된 카드 {card_number}이 다시 등록되었습니다.',
                        'card_number': card.number
                    })
            
            # 새로운 매핑이 생성된 경우
            if created:
                logger.info(f"새 카드 등록 성공: {card_number} (주유소: {request.user.username})")
                message = f'새로운 카드 {card_number}이 성공적으로 등록되었습니다.'
            else:
                logger.info(f"기존 카드 매핑 성공: {card_number} (주유소: {request.user.username})")
                message = f'기존 카드 {card_number}이 이 주유소에 등록되었습니다.'
            
            return JsonResponse({
                'status': 'success',
                'message': message,
                'card_number': card.number
            })
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON 디코딩 오류: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': '잘못된 요청 형식입니다.'
            }, status=400)
        except Exception as e:
            logger.error(f"카드 등록 중 예외 발생: {str(e)}", exc_info=True)
            return JsonResponse({
                'status': 'error',
                'message': f'카드 등록 중 오류가 발생했습니다: {str(e)}'
            }, status=500)
    
    logger.warning(f"잘못된 요청 방식: {request.method}")
    return JsonResponse({'status': 'error', 'message': '잘못된 요청 방식입니다.'}, status=405)

@login_required
def update_card_status(request):
    """카드 사용 상태 업데이트"""
    if not request.user.is_station:
        logger.warning(f"권한 없는 사용자의 상태 업데이트 시도: {request.user.username}")
        return JsonResponse({'status': 'error', 'message': '권한이 없습니다.'}, status=403)
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            card_number = data.get('cardNumber', '').strip()
            is_used = data.get('isUsed', False)
            
            # 입력 검증
            if not card_number or len(card_number) != 16 or not card_number.isdigit():
                return JsonResponse({
                    'status': 'error',
                    'message': '카드번호가 올바르지 않습니다.'
                })
            
            # 카드와 매핑 상태 업데이트
            try:
                # 카드 존재 여부 확인
                card = PointCard.objects.get(number=card_number)
                
                # 현재 주유소의 카드 매핑 확인
                mapping = StationCardMapping.objects.get(
                    station=request.user,
                    card=card,
                    is_active=True
                )
                
                # 카드 상태 업데이트
                old_status = card.is_used
                card.is_used = is_used
                card.save()
                
                # 상태 변경 로깅
                logger.info(
                    f"카드 상태 변경: {card_number}, "
                    f"주유소: {request.user.username}, "
                    f"이전 상태: {'사용중' if old_status else '미사용'}, "
                    f"변경 상태: {'사용중' if is_used else '미사용'}"
                )
                
                return JsonResponse({
                    'status': 'success',
                    'message': '카드 상태가 업데이트되었습니다.',
                    'cardNumber': card.number,
                    'isUsed': card.is_used
                })
            except PointCard.DoesNotExist:
                logger.warning(f"존재하지 않는 카드 상태 업데이트 시도: {card_number}")
                return JsonResponse({
                    'status': 'error',
                    'message': '등록되지 않은 카드번호입니다.'
                })
            except StationCardMapping.DoesNotExist:
                logger.warning(f"권한 없는 카드 상태 업데이트 시도: {card_number}, 주유소: {request.user.username}")
                return JsonResponse({
                    'status': 'error',
                    'message': '해당 카드에 대한 권한이 없습니다.'
                })
            
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': '잘못된 요청 형식입니다.'
            }, status=400)
        except Exception as e:
            logger.error(f"카드 상태 업데이트 중 오류 발생: {str(e)}", exc_info=True)
            return JsonResponse({
                'status': 'error',
                'message': f'카드 상태 업데이트 중 오류가 발생했습니다: {str(e)}'
            }, status=500)
    
    return JsonResponse({'status': 'error', 'message': '잘못된 요청 방식입니다.'}, status=405)

@login_required
def delete_card(request):
    """카드 삭제 (매핑 비활성화)"""
    logger.info(f"카드 삭제 요청 - 사용자: {request.user.username}, 메소드: {request.method}")
    
    if not request.user.is_station:
        logger.warning(f"권한 없는 사용자의 카드 삭제 시도: {request.user.username}")
        return JsonResponse({'status': 'error', 'message': '권한이 없습니다.'}, status=403)
    
    if request.method == 'POST':
        try:
            logger.info(f"요청 본문: {request.body.decode('utf-8')}")
            data = json.loads(request.body)
            card_number = data.get('cardNumber', '').strip()
            logger.info(f"삭제할 카드번호: '{card_number}'")
            
            # 입력 검증
            if not card_number:
                logger.warning("카드번호가 제공되지 않음")
                return JsonResponse({
                    'status': 'error',
                    'message': '카드번호가 필요합니다.'
                })
            
            # 카드 조회
            try:
                card = PointCard.objects.get(number=card_number)
                logger.info(f"카드 찾음: {card.number}")
            except PointCard.DoesNotExist:
                logger.error(f"카드를 찾을 수 없음: {card_number}")
                return JsonResponse({
                    'status': 'error',
                    'message': '카드를 찾을 수 없습니다.'
                }, status=404)
            
            # 주유소-카드 매핑 조회
            try:
                mapping = StationCardMapping.objects.get(
                    station=request.user,
                    card=card,
                    is_active=True
                )
                logger.info(f"매핑 찾음: 주유소={request.user.username}, 카드={card_number}")
            except StationCardMapping.DoesNotExist:
                # 비활성화된 매핑이 있는지 확인
                inactive_mapping = StationCardMapping.objects.filter(
                    station=request.user,
                    card=card,
                    is_active=False
                ).first()
                
                if inactive_mapping:
                    logger.warning(f"이미 삭제된 카드 재삭제 시도: 주유소={request.user.username}, 카드={card_number}")
                    return JsonResponse({
                        'status': 'error',
                        'message': '이 카드는 이미 삭제되었습니다.'
                    }, status=400)
                else:
                    logger.error(f"등록되지 않은 카드 삭제 시도: 주유소={request.user.username}, 카드={card_number}")
                    return JsonResponse({
                        'status': 'error',
                        'message': '이 주유소에 등록된 카드가 아닙니다.'
                    }, status=404)
            
            # 카드가 사용중인지 확인
            if card.is_used:
                logger.warning(f"사용중인 카드 삭제 시도: {card_number}")
                return JsonResponse({
                    'status': 'error',
                    'message': '사용중인 카드는 삭제할 수 없습니다. 먼저 미사용 상태로 변경해주세요.'
                })
            
            # 매핑 비활성화 (실제 삭제 대신)
            mapping.is_active = False
            mapping.save()
            logger.info(f"카드 매핑 비활성화 완료: {card_number}")
            
            return JsonResponse({
                'status': 'success',
                'message': f'카드 {card_number}이(가) 성공적으로 삭제되었습니다.'
            })
            
        except json.JSONDecodeError:
            logger.error("JSON 디코딩 오류")
            return JsonResponse({
                'status': 'error',
                'message': '잘못된 요청 형식입니다.'
            }, status=400)
        except Exception as e:
            logger.error(f"카드 삭제 중 오류 발생: {str(e)}", exc_info=True)
            return JsonResponse({
                'status': 'error',
                'message': f'카드 삭제 중 오류가 발생했습니다: {str(e)}'
            }, status=500)
    
    return JsonResponse({'status': 'error', 'message': '잘못된 요청 방식입니다.'}, status=405)

@login_required
def station_couponmanage(request):
    """주유소 쿠폰 관리 페이지"""
    if not request.user.is_station:
        messages.error(request, '주유소 회원만 접근할 수 있습니다.')
        return redirect('home')
    
    context = {
        'station_name': request.user.username,
        'total_coupons': 0,
        'used_coupons': 0,
        'unused_coupons': 0
    }
    
    return render(request, 'Cust_Station/station_couponmanage.html', context)

@login_required
def get_unused_cards(request):
    """미사용 카드 목록 조회"""
    logger.debug("\n=== 미사용 카드 목록 조회 시작 ===")
    logger.debug(f"요청 사용자: {request.user.username}")
    
    if not request.user.is_station:
        logger.warning(f"권한 없는 사용자 접근: {request.user.username}")
        return JsonResponse({'status': 'error', 'message': '권한이 없습니다.'}, status=403)
    
    try:
        # 현재 주유소에 등록된 카드 중 미사용 카드만 조회 (중복 제거)
        unused_cards = PointCard.objects.filter(
            stations=request.user,
            is_used=False,
            stationcardmapping__is_active=True,
            stationcardmapping__station=request.user
        ).distinct()
        
        # SQL 쿼리 로깅
        logger.debug("\n=== SQL 쿼리 ===")
        logger.debug(str(unused_cards.query))
        
        # 전체 카드 수 로깅
        total_cards = PointCard.objects.count()
        logger.debug(f"\n전체 카드 수: {total_cards}")
        
        # 전체 미사용 카드 수 로깅
        total_unused = PointCard.objects.filter(is_used=False).count()
        logger.debug(f"전체 미사용 카드 수: {total_unused}")
        
        # 현재 주유소의 미사용 카드 수 로깅
        station_unused = unused_cards.count()
        logger.debug(f"현재 주유소의 미사용 카드 수: {station_unused}")
        
        # 카드 번호 목록 생성
        cards = list(unused_cards.values_list('number', flat=True))
        
        # 각 카드 번호 로깅
        logger.debug("\n=== 카드 번호 목록 ===")
        for i, card in enumerate(cards, 1):
            logger.debug(f"{i}. {card}")
        
        logger.debug("\n=== 미사용 카드 목록 조회 완료 ===")
        
        return JsonResponse({
            'status': 'success',
            'cards': cards,
            'total_count': len(cards)
        })
    except Exception as e:
        logger.error(f"오류 발생: {str(e)}")
        logger.error(f"오류 위치: {e.__traceback__.tb_frame.f_code.co_filename}:{e.__traceback__.tb_lineno}")
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=500)

@login_required
def register_customer(request):
    """신규 고객 등록 또는 기존 고객 정보 업데이트"""
    if not request.user.is_station:
        return JsonResponse({'status': 'error', 'message': '권한이 없습니다.'}, status=403)
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            phone = data.get('phone')
            card_number = data.get('card_number')
            
            # 필수 필드 확인
            if not phone or not card_number:
                return JsonResponse({
                    'status': 'error',
                    'message': '전화번호와 카드번호는 필수입니다.'
                }, status=400)
            
            # 전화번호 형식 확인
            if not re.match(r'^\d{10,11}$', phone):
                return JsonResponse({
                    'status': 'error',
                    'message': '올바른 전화번호 형식이 아닙니다.'
                }, status=400)
            
            # 카드 존재 여부 확인
            try:
                card = PointCard.objects.get(number=card_number)
            except PointCard.DoesNotExist:
                return JsonResponse({
                    'status': 'error',
                    'message': '존재하지 않는 카드번호입니다.'
                }, status=404)
            
            # 카드 사용 여부 확인
            if card.is_used:
                return JsonResponse({
                    'status': 'error',
                    'message': '이미 사용중인 카드입니다.'
                }, status=400)
            
            # 현재 주유소와 매핑된 고객들의 전화번호 확인
            existing_relation = CustomerStationRelation.objects.filter(
                station=request.user,
                customer__username=phone
            ).first()
            
            if existing_relation:
                return JsonResponse({
                    'status': 'error',
                    'message': '이미 등록된 전화번호입니다.'
                }, status=400)
            
            try:
                # 전화번호로 기존 사용자 찾기
                existing_user = CustomUser.objects.filter(username=phone).first()
                
                if existing_user:
                    # 기존 사용자가 있는 경우
                    logger.info(f"기존 사용자 발견: {phone}, 정보 업데이트 시작")
                    
                    # CustomerProfile 업데이트 또는 생성
                    customer_profile, created = CustomerProfile.objects.get_or_create(
                        user=existing_user,
                        defaults={'customer_phone': phone}
                    )
                    
                    # 포인트카드 번호만 업데이트
                    customer_profile.bonus_card = card_number
                    customer_profile.save()
                    
                    # 주유소-고객 관계 생성 (get_or_create 사용)
                    relation, created = CustomerStationRelation.objects.get_or_create(
                        customer=existing_user,
                        station=request.user
                    )
                    
                    if not created:
                        return JsonResponse({
                            'status': 'error',
                            'message': '이미 등록된 고객입니다.'
                        }, status=400)
                    
                    # 카드를 사용중으로 변경
                    card.is_used = True
                    card.save()
                    
                    logger.info(f"기존 고객 정보 업데이트 완료: {phone}, 카드: {card_number}, 주유소: {request.user.username}")
                    
                    return JsonResponse({
                        'status': 'success',
                        'message': '고객 정보가 성공적으로 업데이트되었습니다.',
                        'customer': {
                            'id': existing_user.id,
                            'username': existing_user.username,
                            'phone': phone,
                            'card_number': card_number
                        }
                    })
                else:
                    # 신규 고객 생성
                    new_customer = CustomUser.objects.create_user(
                        username=phone,
                        password=card_number,
                        user_type='CUSTOMER'
                    )
                    
                    # CustomerProfile 생성
                    customer_profile = CustomerProfile.objects.create(
                        user=new_customer,
                        customer_phone=phone,
                        bonus_card=card_number
                    )
                    
                    # 주유소-고객 관계 생성 (get_or_create 사용)
                    relation, created = CustomerStationRelation.objects.get_or_create(
                        customer=new_customer,
                        station=request.user
                    )
                    
                    if not created:
                        return JsonResponse({
                            'status': 'error',
                            'message': '이미 등록된 고객입니다.'
                        }, status=400)
                    
                    # 카드를 사용중으로 변경
                    card.is_used = True
                    card.save()
                    
                    logger.info(f"신규 고객 등록 완료: {phone}, 카드: {card_number}, 주유소: {request.user.username}")
                    
                    return JsonResponse({
                        'status': 'success',
                        'message': '고객이 성공적으로 등록되었습니다.',
                        'customer': {
                            'id': new_customer.id,
                            'username': new_customer.username,
                            'phone': phone,
                            'card_number': card_number
                        }
                    })
                    
            except Exception as e:
                logger.error(f"고객 등록/업데이트 중 오류 발생: {str(e)}", exc_info=True)
                return JsonResponse({
                    'status': 'error',
                    'message': f'고객 등록/업데이트 중 오류가 발생했습니다: {str(e)}'
                }, status=500)
                
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': '잘못된 요청 형식입니다.'
            }, status=400)
        except Exception as e:
            logger.error(f"예상치 못한 오류 발생: {str(e)}", exc_info=True)
            return JsonResponse({
                'status': 'error',
                'message': f'예상치 못한 오류가 발생했습니다: {str(e)}'
            }, status=500)
    
    return JsonResponse({
        'status': 'error',
        'message': '잘못된 요청 메소드입니다.'
    }, status=405)

@login_required
def delete_customer(request):
    """고객 삭제 (주유소에서 제외)"""
    if not request.user.is_station:
        return JsonResponse({'status': 'error', 'message': '권한이 없습니다.'}, status=403)
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            customer_id = data.get('customer_id')
            
            # 고객 정보 조회
            customer = get_object_or_404(CustomUser, id=customer_id, user_type='CUSTOMER')
            
            try:
                # 고객 프로필 조회
                profile = customer.customer_profile
                
                # 포인트카드가 있으면 미사용 상태로 변경
                if profile.bonus_card:
                    try:
                        card = PointCard.objects.get(number=profile.bonus_card)
                        card.is_used = False
                        card.save()
                        logger.info(f"포인트카드 미사용 처리: {profile.bonus_card}")
                    except PointCard.DoesNotExist:
                        logger.warning(f"포인트카드를 찾을 수 없음: {profile.bonus_card}")
                
                # 주유소-고객 관계 삭제
                relation = CustomerStationRelation.objects.filter(
                    customer=customer,
                    station=request.user
                ).first()
                
                if relation:
                    relation.delete()
                    logger.info(f"주유소-고객 관계 삭제: {customer.username} - {request.user.username}")
                
                return JsonResponse({
                    'status': 'success',
                    'message': '고객이 삭제되었습니다.',
                    'customer_id': customer_id
                })
                
            except CustomerProfile.DoesNotExist:
                logger.error(f"고객 프로필을 찾을 수 없음: {customer.username}")
                return JsonResponse({
                    'status': 'error',
                    'message': '고객 프로필을 찾을 수 없습니다.'
                }, status=404)
                
        except CustomUser.DoesNotExist:
            return JsonResponse({
                'status': 'error',
                'message': '고객을 찾을 수 없습니다.'
            }, status=404)
        except Exception as e:
            logger.error(f"고객 삭제 중 오류 발생: {str(e)}", exc_info=True)
            return JsonResponse({
                'status': 'error',
                'message': f'처리 중 오류가 발생했습니다: {str(e)}'
            }, status=500)
    
    return JsonResponse({'status': 'error', 'message': '잘못된 요청 방식입니다.'}, status=405)
