// Oil Note PWA Service Worker
const CACHE_NAME = 'oil-note-v8';
const urlsToCache = [
  '/',
  '/manifest.json',
  '/icon-192x192.png',
  '/icon-512x512.png',
  // CDN 파일들
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://code.jquery.com/jquery-3.7.1.min.js',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
  // Font Awesome 웹폰트들
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/webfonts/fa-solid-900.woff2',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/webfonts/fa-regular-400.woff2',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/webfonts/fa-brands-400.woff2'
];

// Service Worker 설치 이벤트
self.addEventListener('install', function(event) {
  console.log('[SW] Install event');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache) {
        console.log('[SW] Opened cache');
        return cache.addAll(urlsToCache);
      })
      .catch(function(error) {
        console.log('[SW] Cache addAll failed:', error);
      })
  );
});

// Service Worker 활성화 이벤트
self.addEventListener('activate', function(event) {
  console.log('[SW] Activate event');
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.map(function(cacheName) {
          if (cacheName !== CACHE_NAME) {
            console.log('[SW] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// 네트워크 요청 가로채기
self.addEventListener('fetch', function(event) {
  // 확장 프로그램 요청 무시
  if (event.request.url.startsWith('chrome-extension://') || 
      event.request.url.startsWith('moz-extension://') ||
      event.request.url.startsWith('safari-extension://') ||
      event.request.url.startsWith('ms-browser-extension://')) {
    return;
  }

  // POST 요청은 항상 네트워크로 전달
  if (event.request.method === 'POST') {
    return fetch(event.request);
  }

  // CSRF 토큰이 포함된 요청은 캐시하지 않음
  if (event.request.headers.get('X-CSRFToken')) {
    return fetch(event.request);
  }

  event.respondWith(
    caches.match(event.request)
      .then(function(response) {
        // 캐시에서 찾은 경우
        if (response) {
          // HTML 페이지의 경우 네트워크 우선 전략 사용
          if (event.request.destination === 'document') {
            return fetch(event.request)
              .then(function(networkResponse) {
                return networkResponse;
              })
              .catch(function() {
                return response;
              });
          }
          return response;
        }

        // 캐시에 없는 경우 네트워크에서 가져오기
        return fetch(event.request).then(
          function(response) {
            // 유효한 응답인지 확인
            if(!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // HTML 페이지는 캐시하지 않음 (CSRF 토큰 때문)
            if (event.request.destination === 'document') {
              return response;
            }

            // 정적 자원만 캐시
            if (event.request.url.startsWith('http://') || event.request.url.startsWith('https://')) {
              var responseToCache = response.clone();
              caches.open(CACHE_NAME)
                .then(function(cache) {
                  cache.put(event.request, responseToCache);
                })
                .catch(function(error) {
                  console.log('[SW] Cache put failed:', error);
                });
            }

            return response;
          }
        ).catch(function(error) {
          console.log('[SW] Fetch failed:', error);
          
          // 오프라인 상태에서 메인 페이지 요청 시 캐시된 홈페이지 반환
          if (event.request.destination === 'document') {
            return caches.match('/');
          }
        });
      })
  );
});

// 백그라운드 동기화 (향후 확장 가능)
self.addEventListener('sync', function(event) {
  console.log('[SW] Background sync:', event.tag);
  if (event.tag === 'background-sync') {
    event.waitUntil(doBackgroundSync());
  }
});

// 푸시 알림 처리 (향후 확장 가능)
self.addEventListener('push', function(event) {
  console.log('[SW] Push received');
  
  const options = {
    body: event.data ? event.data.text() : 'Oil Note 알림',
    icon: '/icon-192x192.png',
    badge: '/icon-192x192.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    }
  };

  event.waitUntil(
    self.registration.showNotification('Oil Note', options)
  );
});

// 백그라운드 동기화 함수
function doBackgroundSync() {
  console.log('[SW] Performing background sync');
  // 향후 오프라인 데이터 동기화 로직 구현
  return Promise.resolve();
} 