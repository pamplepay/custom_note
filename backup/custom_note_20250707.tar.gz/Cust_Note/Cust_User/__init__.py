default_app_config = 'Cust_User.apps.CustUserConfig'
