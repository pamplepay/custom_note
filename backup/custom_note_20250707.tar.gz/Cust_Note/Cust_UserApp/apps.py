from django.apps import AppConfig


class CustUserappConfig(AppConfig):
    name = 'Cust_UserApp'
    verbose_name = '고객 관리' 